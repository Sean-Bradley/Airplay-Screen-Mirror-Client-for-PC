please install BonjourPSSetup.exe first , then it would auto start 'Bonjour Service'
run easyAirplay.exe to enjoy the airplay
